#!/bin/bash
#echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc;
echo "source /opt/ros/noetic/setup.bash" >> ~/.bashrc;
echo "export ROS_MASTER_URI=http://192.168.99.148:11311" >> ~/.bashrc;
echo "export ROS_IP=192.168.99.148" >> ~/.bashrc;
source ~/.bashrc
source /opt/ros/noetic/setup.bash
nohup roscore > /dev/null 2>&1 &

while true
do
    echo "hello world"
    sleep 200
done
